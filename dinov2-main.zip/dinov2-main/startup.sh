#!/bin/bash
/home/miniconda3/envs/sewer2/bin/python /mnt/f/PyProjects/dinov2-main/main.py $1
