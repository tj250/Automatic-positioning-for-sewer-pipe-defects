import os
import time
import cv2
import natsort
import numpy as np
import math
import matplotlib
from PIL import Image
import torch
from torchvision import transforms
import torch.nn.functional as F
from functools import partial
import itertools
import mmcv
from mmcv.runner import load_checkpoint
from dinov2.eval.depth.models import build_depther
import threading

class CenterPadding(torch.nn.Module):
    def __init__(self, multiple):
        super().__init__()
        self.multiple = multiple

    def _get_pad(self, size):
        new_size = math.ceil(size / self.multiple) * self.multiple
        pad_size = new_size - size
        pad_size_left = pad_size // 2
        pad_size_right = pad_size - pad_size_left
        return pad_size_left, pad_size_right

    @torch.inference_mode()
    def forward(self, x):
        pads = list(itertools.chain.from_iterable(self._get_pad(m) for m in x.shape[:1:-1]))
        output = F.pad(x, pads)
        return output


def create_depther(cfg, backbone_model, backbone_size, head_type):
    train_cfg = cfg.get("train_cfg")
    test_cfg = cfg.get("test_cfg")
    depther = build_depther(cfg.model, train_cfg=train_cfg, test_cfg=test_cfg)

    depther.backbone.forward = partial(
        backbone_model.get_intermediate_layers,
        n=cfg.model.backbone.out_indices,
        reshape=True,
        return_class_token=cfg.model.backbone.output_cls_token,
        norm=cfg.model.backbone.final_norm,
    )

    if hasattr(backbone_model, "patch_size"):
        depther.backbone.register_forward_pre_hook(lambda _, x: CenterPadding(backbone_model.patch_size)(x[0]))

    return depther

def make_depth_transform() -> transforms.Compose:
    return transforms.Compose([
        transforms.ToTensor(),
        lambda x: 255.0 * x[:3], # Discard alpha component and scale by 255
        transforms.Normalize(
            mean=(123.675, 116.28, 103.53),
            std=(58.395, 57.12, 57.375),
        ),
    ])


def render_depth(values, colormap_name="magma_r") -> Image:
    min_value, max_value = values.min(), values.max()
    normalized_values = (values - min_value) / (max_value - min_value)

    colormap = matplotlib.colormaps[colormap_name]
    colors = colormap(normalized_values, bytes=True) # ((1)xhxwx4)
    colors = colors[:, :, :3] # Discard alpha component
    return Image.fromarray(colors)

def estimate_depth(data_dir, conn, record_id):
    images_directory = os.path.join(data_dir, "origin_data")
    # filter_frames_by_depth_information(images_directory, conn, record_id)
    # return
    start_dt = time.localtime()
    treadingMaxCount = 1
    models = []

    current_directory = r'/mnt/f/PyProjects/dinov2-main'
    for i in range(treadingMaxCount):
        BACKBONE_SIZE = "large" # in ("small", "base", "large" or "giant")
        backbone_archs = {"small": "vits14", "base": "vitb14", "large": "vitl14", "giant": "vitg14",}
        backbone_arch = backbone_archs[BACKBONE_SIZE]
        backbone_name = f"dinov2_{backbone_arch}"
        backbone_model = torch.hub.load(repo_or_dir=current_directory, source='local', model=backbone_name)
        backbone_model.eval()
        backbone_model.cuda()

        HEAD_TYPE = "dpt" # in ("linear", "linear4", "dpt")
        if BACKBONE_SIZE == "giant":
            cfg = mmcv.Config.fromfile(current_directory + '/pipeline/dinov2_vitg14_nyu_dpt_config.py') # giant
        elif BACKBONE_SIZE == "large":
            cfg = mmcv.Config.fromfile(current_directory + '/pipeline/dinov2_vitl14_nyu_dpt_config.py')  # large
        elif BACKBONE_SIZE == "base":
            cfg = mmcv.Config.fromfile(current_directory + '/pipeline/dinov2_vitb14_nyu_dpt_config.py') # base
        else:
            cfg = mmcv.Config.fromfile(current_directory + '/pipeline/dinov2_vits14_nyu_dpt_config.py')  # small
        model = create_depther(cfg, backbone_model=backbone_model, backbone_size=BACKBONE_SIZE, head_type=HEAD_TYPE,)
        if BACKBONE_SIZE == "giant":
            load_checkpoint(model, current_directory + '/pipeline/dinov2_vitg14_nyu_dpt_head.pth', map_location="cuda:0") # giant
        elif BACKBONE_SIZE == "large":
            load_checkpoint(model, current_directory + '/pipeline/dinov2_vitl14_nyu_dpt_head.pth', map_location="cuda:0") # large
        elif BACKBONE_SIZE == "base":
            load_checkpoint(model, current_directory + '/pipeline/dinov2_vitb14_nyu_dpt_head.pth', map_location="cuda:0") # base
        else:
            load_checkpoint(model, current_directory + '/pipeline/dinov2_vits14_nyu_dpt_head.pth', map_location="cuda:0") # small
        model.eval()
        model.cuda()
        models.append(model)

    depth_img_dir = os.path.join(data_dir , 'depth_map')
    if not os.path.exists(depth_img_dir):
        os.mkdir(depth_img_dir)

    files = os.listdir(images_directory)
    files = natsort.natsorted(files)

    total_frames = int(len(files)/2)

    threads = []
    for one_file in files:
        if not one_file.endswith(".jpg") or one_file.endswith("_depth.jpg"):
            continue

        depth_file_path = os.path.join(depth_img_dir, one_file[0:-4] + "_depth.jpg")
        if os.path.isfile(depth_file_path):
            continue

        # if len(threads) < treadingMaxCount:
        #     t = threading.Thread(target=create_one_depth_image,
        #                          args=(images_directory, one_file, models[0], depth_img_dir))
        #     t.start()
        #     threads.append(t)
        # else:
        #     dealed = False
        #     while not dealed:
        #         for i in range(len(threads)):
        #             if not threads[i].is_alive(): # 线程已执行完毕
        #                 threads[i] = threading.Thread(target=create_one_depth_image,
        #                                      args=(images_directory, one_file, models[i], depth_img_dir))
        #                 threads[i].start()
        #                 dealed = True
        #                 print(str(i))
        #                 break
        #         if not dealed: # 未找到空闲线程
        #             print("begin wait ...")
        #             time.sleep(1)

        file_path = os.path.join(images_directory, one_file)
        print(file_path)
        image = Image.open(file_path).convert("RGB")
        transform = make_depth_transform()

        rescaled_image = image.resize((image.width, image.height))
        transformed_image = transform(rescaled_image)
        batch = transformed_image.unsqueeze(0).cuda() # Make a batch of one image

        with torch.inference_mode():
            result = models[0].whole_inference(batch, img_meta=None, rescale=True)

        depth_image = render_depth(result.squeeze().cpu(), colormap_name='gray') # colormap_name='magma_r'
        # depth_image.show()
        depth_img_file_path = os.path.join(depth_img_dir, os.path.basename(file_path)[0:-4] + "_depth.jpg")
        depth_image.save(depth_img_file_path)

    print('total frames:{}'.format(total_frames))

    # remove frames with abnormal depth information
    filter_frames_by_depth_information(images_directory, conn, record_id)

    # statistical infomation
    end_dt = time.localtime()
    sql = "update procedure set depth_esti_start_dt='{}',depth_esti_end_dt='{}',depth_esti_used_seconds={} where record_id='{}'".format(
        time.strftime("%Y-%m-%d %H:%M:%S", start_dt), time.strftime("%Y-%m-%d %H:%M:%S", end_dt),
        time.mktime(end_dt) - time.mktime(start_dt), record_id)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()

    print('estimate_images_depth finished')

'''
step2-2:Removing anomalous frames through depth information
'''
def filter_frames_by_depth_information(images_directory, conn, record_id):
    data_dir = os.path.dirname(images_directory)
    depth_files_dir = os.path.join(data_dir, 'depth_map')
    files = os.listdir(depth_files_dir)
    files = natsort.natsorted(files)

    err_dir = os.path.join(data_dir, "depth_map_abnormal")
    if not os.path.exists(err_dir):
        os.mkdir(err_dir)

    total_frames = len(files)
    counter = 0

    main_body_mode = False # 是否进入严格检测模式
    for one_file in files:
        with open(os.path.join(images_directory, one_file[:-10] + '.txt'), 'r') as file:
            this_frame_distance = float(file.read())  # 当前帧上显示的距离数值
        if not main_body_mode and this_frame_distance > 2: # 已经进入管道内（字幕距离值大于2M），开启严格检测模式，防止图像被错误的排除
            main_body_mode = True
        file_path = os.path.join(depth_files_dir, one_file)
        image = cv2.imdecode(np.fromfile(file_path, dtype=np.uint8), -1)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        (minVal, maxVal, minLoc, maxLoc) = cv2.minMaxLoc(gray)
        # cv2.circle(image, maxLoc, 50, (255, 0, 0), 2)
        # cv2.imencode(".png", image)[1].tofile(os.path.join(images_directory, one_file[0:-10]) + ".png")
        # if one_file == '4724_depth.jpg':
        #     abc = 1
        is_normal = True
        # 第一次检测:最亮点是否在图像中心区域
        if not (maxLoc[0] > image.shape[1] / 4 and maxLoc[0] < image.shape[1] / 4 * 3 and maxLoc[1] > image.shape[0] / 4
                and maxLoc[1] < image.shape[0] / 4 * 3): # 不在
            is_normal = False

        # 第二次检测:图像四个角的区域是否亮度过大，如果有，则标识图像异常
        if is_normal:
            w_test = int(image.shape[1] / 20);
            h_test = int(image.shape[0] / 20);
            corners_region = [(0,0),(image.shape[1] - w_test, 0),(image.shape[1] - w_test, image.shape[0]-h_test),
                              (0, image.shape[0]-h_test)]
            for corner in corners_region:
                total_gray_value = 0
                for w in range(w_test):
                    for h in range(h_test):
                        total_gray_value += gray[corner[1]+h][corner[0]+w]
                if total_gray_value / (w_test * h_test) > (150 if main_body_mode else 60): # 某一角过亮
                    is_normal = False
                    break

        # 第三次检测:圆周上亮点和暗点差异是否过大
        if is_normal:
            sampling_points_number = 32
            radius = min(min(maxLoc[0], image.shape[1] - maxLoc[0]), min(maxLoc[1], image.shape[0] - maxLoc[1])) - 1
            sampleing_points = get_circle_sample_points(maxLoc[0], maxLoc[1], radius, sampling_points_number) # 计算以最亮点为中心的圆周上的采样点坐标
            # 去掉N个最暗和最亮的点
            iter_times = int(len(sampleing_points) * 0.1)  # 删除10%的最大和最小亮度值
            for m in range(iter_times):
                point_max_value = -1
                point_min_value = 1000
                for point in sampleing_points:
                    point_gray_value = gray[point[1]][point[0]]
                    point_max_value = max(point_gray_value, point_max_value)
                    point_min_value = min(point_gray_value, point_min_value)
                for k in range(len(sampleing_points)-1, -1, -1):
                    point = sampleing_points[k]
                    if gray[point[1]][point[0]] == point_max_value:
                        del sampleing_points[k]
                        break
                for k in range(len(sampleing_points) - 1, -1, -1):
                    point = sampleing_points[k]
                    if gray[point[1]][point[0]] == point_min_value:
                        del sampleing_points[k]
                        break
            # 重新搜索一次
            point_max_value = -1
            point_min_value = 1000
            for point in sampleing_points:
                point_gray_value = gray[point[1]][point[0]]
                point_max_value = max(point_gray_value, point_max_value)
                point_min_value = min(point_gray_value, point_min_value)
            if point_max_value - point_min_value > 100: # 次最亮点和次最暗点的灰度值偏差过大（排除偶发的干扰）
                is_normal = False

            # 第四次检测，仅在尚未进入管道主体的情况下（避免排除一些深度估计效果不好，但是正常的帧），检测不同半径圆周像素灰度值均值是否从亮变暗
            if is_normal and radius > 100: # 最亮点过小时（图像是小尺寸，并且最亮点在比较靠近图像边缘时才会发生）
                gray_values = []
                for i in range(int(radius / 100)):
                    radius_i = (i + 1) * 100
                    sampleing_points = get_circle_sample_points(maxLoc[0], maxLoc[1], radius_i, sampling_points_number)  # 计算以最亮点为中心的圆周上的采样点坐标
                    gray_value = 0
                    for point in sampleing_points:
                        gray_value += gray[point[1]][point[0]]
                        # cv2.circle(gray, point, 1, 255, -1)  # -1表示填充颜色
                    gray_values.append(gray_value / len(sampleing_points)) # 圆周采样点的灰度值的平均值

                if radius % 100 / 10 > 0: # 将外围也做一次采样
                    sampleing_points = get_circle_sample_points(maxLoc[0], maxLoc[1], radius, sampling_points_number) # 计算以最亮点为中心的圆周上的采样点坐标
                    gray_value = 0
                    for point in sampleing_points:
                        gray_value += gray[point[1]][point[0]]
                        # cv2.circle(gray, point, 1, 255, -1)  # -1表示填充颜色
                    gray_values.append(gray_value / len(sampleing_points)) # 圆周采样点的灰度值的平均值
                for i in range(len(gray_values)-1): # 检测是否围绕最亮点，逐圈变暗
                    if i == 0:
                        threashold = 30
                    else:
                        threashold = -5
                    if gray_values[i] - gray_values[i+1] < threashold:
                        is_normal = False
                        break
                # cv2.imwrite(r'/mnt/f/a.jpg', gray)

        if not is_normal:
            os.rename(file_path, os.path.join(err_dir, os.path.basename(file_path)))
            if os.path.exists(os.path.join(images_directory, one_file[0:-10]+ ".jpg")):
                os.rename(os.path.join(images_directory, one_file[0:-10]+ ".jpg") , os.path.join(err_dir, one_file[0:-10] + ".jpg"))
            if os.path.exists(os.path.join(images_directory, one_file[0:-10]+ ".txt")):
                os.rename(os.path.join(images_directory, one_file[0:-10] + ".txt"),
                          os.path.join(err_dir, one_file[0:-10] + ".txt"))
            print("remove frame:", os.path.join(images_directory, one_file[0:-10] + ".jpg"), str(image.shape[1] / 4), "-", str(maxLoc[0]), "-",str(image.shape[1] / 4 * 3),
                  str(image.shape[0] / 4), "-", str(maxLoc[1]), "-", str(image.shape[0] / 4 * 3))
            counter += 1

    print('total frames:{}, exclude frames:{}, left frames:{}'.format(total_frames, counter, total_frames - counter))
    print('filter_frames_by_depth_information finished')

    # statistical infomation
    sql = "update procedure set depth_esti_excluded_frames={},frames_after_depth_esti={} where record_id='{}'".format(counter,
        total_frames - counter, record_id)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()

# 读取视频帧，每次调用会整体对一个视频文件进行读取
def create_one_depth_image(images_directory, one_file, model, depth_img_dir):
    file_path = os.path.join(images_directory, one_file)
    print(file_path)
    image = Image.open(file_path).convert("RGB")
    transform = make_depth_transform()

    rescaled_image = image.resize((image.width, image.height))
    transformed_image = transform(rescaled_image)
    batch = transformed_image.unsqueeze(0).cuda()  # Make a batch of one image

    with torch.inference_mode():
        result = model.whole_inference(batch, img_meta=None, rescale=True)

    depth_image = render_depth(result.squeeze().cpu(), colormap_name='gray')
    # depth_image.show()
    depth_img_file_path = os.path.join(depth_img_dir, os.path.basename(file_path)[0:-4] + "_depth.jpg")
    depth_image.save(depth_img_file_path)

# 获取圆周上的采样点坐标
def get_circle_sample_points(center_x, center_y, radius, num_points):
    # 计算每个点之间的角度差
    angle_increment = 360.0 / num_points

    # 计算每个点的坐标
    points = []
    for i in range(num_points):
        angle_deg = i * angle_increment  # 角度（度）
        angle_rad = math.radians(angle_deg)  # 角度（弧度）
        x = center_x + radius * math.cos(angle_rad)
        y = center_y + radius * math.sin(angle_rad)
        points.append((int(x), int(y)))
    return points

if __name__ == '__main__':
    estimate_depth(r"/mnt/f/china_sewer/paper/video_data")