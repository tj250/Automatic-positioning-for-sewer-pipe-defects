/home/miniconda3/envs/sewer2/bin/python /mnt/f/abc.py
