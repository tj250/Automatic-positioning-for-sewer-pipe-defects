import sys

import pipeline_depth_estimate
import sqlite3


if __name__ == '__main__':
    video_filename = ''
    if len(sys.argv) > 1:
        video_filename = sys.argv[1]
    if video_filename == '':
        video_filename = 'E.mp4'
    print(video_filename)
    # exit()
    data_dir = r"/mnt/f/china_sewer/paper/" + video_filename[:-4]
    conn = sqlite3.connect('/mnt/f/china_sewer/paper/sewer.db')
    cursor = conn.cursor()
    cursor.execute("SELECT record_id FROM procedure where video_file='{}'".format(video_filename))
    rows = cursor.fetchall()
    if len(rows) == 0:
        print("error")
        exit()
    else:
        record_id = rows[0][0]
    cursor.close()
    # Calling dinov2  to create depth images (also removing some abnormal images with abnormal depth value)
    pipeline_depth_estimate.estimate_depth(data_dir, conn, record_id)

    conn.close()



